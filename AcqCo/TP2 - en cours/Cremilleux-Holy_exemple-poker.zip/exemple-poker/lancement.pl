:- ['/home-reseau/lholy/4INFO/AcqCo2/TP2/aleph.pl'].
:- read_all(poker), set(recordfile,'/dev/null'), set(verbose,0), induce.
